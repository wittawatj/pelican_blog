classdef Ref < handle 
    %REF a class for doing pass by reference.
    
    properties
        obj
    end
    
    methods
    end
    
end
