% Start up file for l1-lsmi
% This adds necessary paths Matlab's search path
%

addpath(genpath(pwd));