JTCC is a Java library developed by Wittawat Jitkrittum (wittawatj (at) gmail.com) to tokenize Thai text into a list of TCCs. JTCC is released under GPLv3 license. 

For more information on JTCC, visit 

http://jtcc.googlecode.com


